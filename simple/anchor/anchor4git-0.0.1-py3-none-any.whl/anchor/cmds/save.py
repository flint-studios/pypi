from typer import Argument, Option
from datetime import datetime
from typing import Optional

from ..data import data
from ..utils import *

# Command for commit saving: `anchor save/s <MESSAGE>` #
def save_cmd(
    message: Optional[list[str]] = Argument(None, help="Message to describe changes."),
    preview: bool = Option(False, "--preview", help="Show what would be saved and exit."),
):
    """Save a snapshot of the entire repository."""

    # ───── SAFETY GATEWAY ────────────────────────────────────────────────── #
    if not is_repo(): die("Local repository does not exist. Get started by running 'anchor fetch <url>' first.")

    if detached(): die("This command is unavailable while actively using 'anchor goto'.")
    
    if not dirty(): return info("Nothing to save. Workspace is clean.")

    # ───── PREPARE DETAILS ────────────────────────────────────────────────── #
    timestmp = datetime.now().strftime("%y%m%d-%H%M%S")
    cfg = cfg_read()

    msg = " ".join(message or []) or f"anchor: Save {timestmp}"
    name = cfg.get("name") or data["default_name"]
    email = cfg.get("email") or data["default_email"]

    # ───── GIT COMMIT  ────────────────────────────────────────────────── #
    git("add", "."); git("reset", CONFIG_FILE)

    if preview:
        preview_block("General Details", [f"Message: {msg}", f"Author name: {name}", f"Author email: {email}"])
        preview_block("Changes", changes().splitlines())
        next_step("running the same command again without --preview to actually use it.")
        return

    git("-c", f'user.name="{name}"', "-c", f'user.email="{email}"', "commit", "-m", msg); ok(f'Saved: "{msg}"'); next_step("running 'anchor upload' when you are ready to publish.")