# ───── DYNAMIC DATA STORE ────────────────────────────────────────────────── #
data = {
    "commands": [ # Available commands
        "info",
        "i",
        "dashboard",
        "save",
        "s",
        "fetch",
        "f",
        "upload",
        "u",
        "goto",
        "g",
        "config",
        "c",
    ],
    "default_name": "Anchor4Git Client",
    "default_email": "anchor@local.dev",
    "tagline": "A highly-minimal workflow tool for small teams using Git.",
    "version": "0.0.1"
}